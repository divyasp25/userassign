const express = require('express');
const router = express.Router();
const Blog = require('../models/blogModel');

router.get('/search', async (req, res) => {
  try {
    const searchQuery = req.query.search;
    const blogs = await Blog.find({ blogTitle: { $regex: searchQuery, $options: 'i' } });
    res.status(200).json(blogs);
  } catch (error) {
    res.status(500).json({ message: 'Failed to search for blog posts' });
  }
});
router.put('/:id', async (req, res) => {
    try {
      const blog = await Blog.findByIdAndUpdate(req.params.id, req.body, { new: true });
      if (!blog) {
        return res.status(404).json({ message: 'Blog not found' });
      }
      res.status(200).json(blog);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update blog by ID' });
    }
  });
router.delete('/:id', async (req, res) => {
try {
    const blog = await Blog.findByIdAndDelete(req.params.id);
    if (!blog) {
    return res.status(404).json({ message: 'Blog not found' });
    }
    res.status(200).json({ message: 'Blog deleted successfully' });
} catch (error) {
    res.status(500).json({ message: 'Failed to delete blog by ID' });
}
});
module.exports = router;