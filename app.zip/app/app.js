const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const jsonfile = require('jsonfile');

const dbPath = 'db.json';

const app = express();
const PORT = 3000;

// Initialize database
const readDatabase = () => jsonfile.readFileSync(dbPath, { throws: false }) || { users: [], blogs: [] };
const writeDatabase = (data) => jsonfile.writeFileSync(dbPath, data, { spaces: 2 });

// Middleware
app.use(bodyParser.json());

// Custom middleware for authentication
const authenticateUser = (req, res, next) => {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, 'secretKey');
    req.user = readDatabase().users.find((user) => user.id === decoded.id);
    next();
  } catch (error) {
    res.status(401).json({ error: 'Unauthorized' });
  }
};
app.get('/', (req, res) => {
  res.send('Welcome to the API');
});

// Routes
app.post('/register', (req, res) => {
  const { username, password } = req.body;

  // Simulated user registration - in real-world, store in a database
  const data = readDatabase();
  const newUser = { id: data.users.length + 1, username, password };
  data.users.push(newUser);
  writeDatabase(data);

  res.status(201).json(newUser);
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = readDatabase().users.find((u) => u.username === username && u.password === password);

  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: user.id }, 'secretKey');
  res.json({ token });
});

app.get('/blogs', authenticateUser, (req, res) => {
  const blogs = readDatabase().blogs;
  res.json(blogs);
});

app.post('/blogs', authenticateUser, (req, res) => {
  const { title, content } = req.body;
  const data = readDatabase();
  const newBlog = { id: data.blogs.length + 1, authorId: req.user.id, title, content };
  data.blogs.push(newBlog);
  writeDatabase(data);

  res.status(201).json(newBlog);
});

app.get('/blogs/:authorId', authenticateUser, (req, res) => {
  const authorId = parseInt(req.params.authorId);
  const authorBlogs = readDatabase().blogs.filter((blog) => blog.authorId === authorId);

  res.json(authorBlogs);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
